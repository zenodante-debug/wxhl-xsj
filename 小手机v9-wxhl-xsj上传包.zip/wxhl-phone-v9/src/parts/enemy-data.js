// Empty defaults verified against 变量结构-特殊资源通用版(3), 装备槽Schema.
// This module validates the phone's output; it never changes the card's MVU schema.
const __wxhlEnemySlots = ['头部','躯干','手部','下装','饰品','主武器','副武器'];
const __wxhlEnemyEmptyValues = Object.freeze({
  名称:'无',类型:'无',品质:'无',阶位:'无',穿戴门槛:'无',强化等级:0,
  伤害骰:'无',倍率:0,主属性:'无',副属性:'无',主属性加成:0,副属性加成:0,
  装备防御:0,装备闪避:0,负重:0,效果:Object.freeze({}),描述:'无',数量:1
});
const __wxhlEnemyObject = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const __wxhlEnemyClone = value => _.cloneDeep(value);
const __wxhlEnemyEmptySlot = () => ({...__wxhlEnemyEmptyValues,效果:{}});
const __wxhlEnemySlotShape = Object.fromEntries(Object.entries(__wxhlEnemyEmptyValues).map(([key,value]) => [
  key,key === '效果' ? d.z.record(d.z.string(),d.z.string())
    : typeof value === 'number' ? d.z.number() : d.z.string().min(1)
]));
const __wxhlEnemySlotSchema = d.z.object(__wxhlEnemySlotShape).catchall(d.z.any());
const __wxhlEnemyEquipmentSchema = d.z.object(Object.fromEntries(
  __wxhlEnemySlots.map(slot => [slot,__wxhlEnemySlotSchema])
)).catchall(d.z.any());
// Stored equipment may rely on the actual card's prefaults. Validate it without
// replacing it with parsed output, which would strip unknown fields or fill values.
const __wxhlEnemyStoredSlotSchema = d.z.object(Object.fromEntries(
  Object.entries(__wxhlEnemyEmptyValues).map(([key,value]) => [
    key,key === '效果'
      ? d.z.union([d.z.record(d.z.string(),d.z.string()),d.z.string()]).prefault({})
      : typeof value === 'number' ? d.z.coerce.number().prefault(value) : d.z.string().prefault(value)
  ])
)).prefault({});
function __wxhlEnemyEquipmentError(name,slot,details) {
  return new Error((name || '未命名角色')+' → 装备'+(slot?' → '+slot:'')+'：'+details);
}
function __wxhlEnemyNormalizeEquipment(value,name) {
  if (value === undefined) value = {};
  if (!__wxhlEnemyObject(value)) throw __wxhlEnemyEquipmentError(name,'','必须是七槽装备对象，不能用文本、null 或数组代替');
  const result = __wxhlEnemyClone(value);
  for (const slot of __wxhlEnemySlots) {
    let item = value[slot];
    if (item === undefined || item === '无' || (__wxhlEnemyObject(item) && Object.keys(item).length === 0)) {
      result[slot] = __wxhlEnemyEmptySlot();
      continue;
    }
    if (!__wxhlEnemyObject(item)) throw __wxhlEnemyEquipmentError(name,slot,'必须是完整装备对象；只兼容明确的空槽文本“无”');
    if (item.名称 === '无') {
      for (const [key,expected] of Object.entries(__wxhlEnemyEmptyValues)) {
        if (!(key in item)) continue;
        const actual = item[key];
        if (key === '效果' ? !__wxhlEnemyObject(actual) || Object.keys(actual).length !== 0 : actual !== expected) {
          throw __wxhlEnemyEquipmentError(name,slot,'名称为“无”但仍有非空装备数据，请核对，系统不会清空这些内容');
        }
      }
      item = {...__wxhlEnemyEmptySlot(),...item};
    }
    const parsed = __wxhlEnemySlotSchema.safeParse(item);
    if (!parsed.success) {
      const problems = parsed.error.issues.map(issue => (issue.path.join('.') || '装备')+'：'+issue.message).join('；');
      throw __wxhlEnemyEquipmentError(name,slot,problems);
    }
    // Copy the original object, not a parsed/stripped projection.
    result[slot] = __wxhlEnemyClone(item);
  }
  return result;
}
// Enemy generation owns bare base values only. The existing frontend owns bonuses,
// actual attributes, modifiers, and derived totals; no frontend formula is changed.
const __wxhlEnemyRawKeys = ['STR','AGI','CON','PER'];
const __wxhlEnemyZeroAttributes = d.z.object(Object.fromEntries(
  __wxhlEnemyRawKeys.map(key => [key,d.z.literal(0).prefault(0)])
)).prefault({});
function __wxhlEnemyAssertRawAttributes(enemy) {
  if (!__wxhlEnemyObject(enemy)) throw new Error('敌人基础数据必须是对象');
  const name = enemy.名称 || '未命名敌人';
  const fail = message => { throw new Error(name+' → 裸基础属性：'+message+'；请重新生成敌人，原结果已保留'); };
  for (const key of ['属性','属性加成','实际属性','属性修正值','修正值','HP_最大','MP_最大','耐力_最大','防御','闪避值','移动距离','负重_上限','HP_当前','MP_当前','耐力_当前']) {
    if (Object.prototype.hasOwnProperty.call(enemy,key)) fail('出现前端计算字段“'+key+'”，生成阶段禁止预计算或回填');
  }
  const base = enemy.属性基础;
  if (!__wxhlEnemyObject(base)) fail('缺少只含 STR/AGI/CON/PER 的属性基础对象');
  if (Object.keys(base).some(key=>!__wxhlEnemyRawKeys.includes(key))) fail('属性基础只能包含四个裸值，不能夹带实际值或修正值');
  const custom = enemy.属性自定义加成;
  if (custom !== undefined && (!__wxhlEnemyObject(custom) || Object.values(custom).some(value=>value!==0))) {
    fail('生成阶段属性自定义加成必须为 0；装备、职业、天赋、血统加成只保留在各自来源字段');
  }
  const values = __wxhlEnemyRawKeys.map(key=>Number(base[key]));
  const tier = j(enemy.阶位),level = Number(enemy.等级);
  const coefficient = {杂兵:0.6,精英:0.9,BOSS:1.2}[enemy.类型];
  if (values.every(Number.isFinite) && Number.isFinite(level) && coefficient !== undefined) {
    if (!Number.isInteger(tier) || tier < 0 || tier > 4) fail('无法识别阶位，不能确认裸属性预算');
    // Keep the original rule and allow its floor/ceil rounding. Never subtract
    // guessed equipment bonuses or silently rebalance the four base values.
    const budget = 30 + level + coefficient * 13 * (tier+1) ** 2;
    const total = values.reduce((sum,value)=>sum+value,0);
    if (total < Math.floor(budget)-1e-8 || total > Math.ceil(budget)+1e-8) {
      fail('四维总和 '+total+' 超出原规则裸值预算 '+Math.floor(budget)+'～'+Math.ceil(budget)+'，不能把属性加成或修正值加进基础值');
    }
  }
  return enemy;
}


function __wxhlEnemyPrepareResponse(value) {
  if (!__wxhlEnemyObject(value) || !Array.isArray(value.敌人)) throw new Error('敌人生成结果缺少“敌人”数组');
  return {...value,敌人:value.敌人.map(enemy => {
    if (!__wxhlEnemyObject(enemy)) throw new Error('敌人条目必须是对象');
    __wxhlEnemyAssertRawAttributes(enemy);
    return {...enemy,装备:__wxhlEnemyNormalizeEquipment(enemy.装备,enemy.名称)};
  })};
}
function __wxhlEnemyScope() {
  const chat = __wxhlCraftChat();
  if (!chat) throw new Error('无法确认当前聊天，已停止写入；请进入角色聊天后重试');
  let floor = -1;
  try {
    const id = typeof getCurrentMessageId === 'function' ? getCurrentMessageId() : -1;
    if (Number.isInteger(id) && id >= 0) floor = id;
  } catch (_) {}
  if (floor < 0 && Array.isArray(chat.host?.chat) && chat.host.chat.length > 0) floor = chat.host.chat.length - 1;
  if (floor < 0) throw new Error('无法确认目标消息楼层，已停止写入');
  return {chatKey:chat.key,floor};
}
function __wxhlEnemyAssertScope(scope) {
  const current = __wxhlEnemyScope();
  if (scope.chatKey !== current.chatKey || scope.floor !== current.floor) {
    throw new Error('聊天或目标楼层已经改变，本次操作已停止，请回到原聊天后重试');
  }
}
const __wxhlEnemyDrafts = new Map();
function __wxhlEnemyDraftKey(scope,id) { return JSON.stringify([scope.chatKey,id]); }
function __wxhlEnemySaveDraft(scope,id,text) { __wxhlEnemyDrafts.set(__wxhlEnemyDraftKey(scope,id),String(text)); }
function __wxhlEnemyDraft(id) {
  try { return __wxhlEnemyDrafts.get(__wxhlEnemyDraftKey(__wxhlEnemyScope(),id)) || ''; }
  catch (_) { return ''; }
}
function __wxhlEnemyBackupKey(scope) {
  return 'wxhl003_enemy_empty_slots_backup_v1:'+encodeURIComponent(JSON.stringify([scope.chatKey,scope.floor]));
}
function __wxhlEnemyRead(scope) {
  __wxhlEnemyAssertScope(scope);
  const data = Mvu.getMvuData({type:'message',message_id:scope.floor});
  if (!__wxhlEnemyObject(data?.stat_data?.契约者)) throw new Error('目标楼层没有契约者存档，未执行修改');
  return data;
}
function __wxhlEnemyRepairPlan(snapshot) {
  const entities = snapshot?.stat_data?.契约者?.副本角色;
  if (entities === undefined) return [];
  if (!__wxhlEnemyObject(entities)) throw new Error('副本角色容器格式异常，未执行修复');
  const changes = [];
  for (const [name,entity] of Object.entries(entities)) {
    if (!__wxhlEnemyObject(entity)) throw new Error(name+'：副本角色不是对象，未执行修复');
    const equipment = entity.装备;
    if (equipment === undefined) continue;
    if (!__wxhlEnemyObject(equipment)) throw __wxhlEnemyEquipmentError(name,'','装备容器不是对象，需要人工核对');
    for (const slot of __wxhlEnemySlots) {
      const item = equipment[slot];
      if (item === '无') {
        changes.push({name,slot,before:'无',after:__wxhlEnemyEmptySlot()});
        continue;
      }
      // Do not normalize or rewrite any existing valid object.
      const valid = __wxhlEnemyStoredSlotSchema.safeParse(item);
      if (!valid.success) throw __wxhlEnemyEquipmentError(name,slot,'存在其他格式问题，未执行修复：'+valid.error.issues.map(x=>x.path.join('.')+' '+x.message).join('；'));
    }
  }
  return changes;
}
function __wxhlEnemyApplyRepair(snapshot,changes) {
  const next = __wxhlEnemyClone(snapshot);
  for (const change of changes) {
    const entity = next.stat_data.契约者.副本角色[change.name];
    if (entity?.装备?.[change.slot] !== change.before) throw new Error('待修复数据已改变，请重新检查');
    entity.装备[change.slot] = __wxhlEnemyClone(change.after);
  }
  return next;
}
async function __wxhlEnemyRepairCurrent() {
  const scope = __wxhlEnemyScope();
  const snapshot = __wxhlEnemyClone(__wxhlEnemyRead(scope));
  const changes = __wxhlEnemyRepairPlan(snapshot);
  if (!changes.length) { toastr.info('当前聊天的目标楼层没有需要修复的敌人空槽'); return false; }
  const preview = changes.map(x=>'· '+x.name+' / '+x.slot+'：“无” → 标准空装备对象').join('\n');
  if (!confirm('修复当前聊天第 '+scope.floor+' 楼的敌人空槽：\n\n'+preview+
    '\n\n只修改以上空槽，保留装备、HP 和其他数据。修复前将保存本地备份。\n确定执行？')) return false;
  __wxhlEnemyAssertScope(scope);
  const fresh = __wxhlEnemyRead(scope);
  if (JSON.stringify(fresh) !== JSON.stringify(snapshot)) throw new Error('预览后存档已改变，未执行修复，请重新检查');
  const next = __wxhlEnemyApplyRepair(snapshot,changes);
  const names = [...new Set(changes.map(x=>x.name))];
  const backup = {version:1,createdAt:new Date().toISOString(),chatKey:scope.chatKey,message_id:scope.floor,changes,
    entities:Object.fromEntries(names.map(name=>[name,__wxhlEnemyClone(snapshot.stat_data.契约者.副本角色[name])]))};
  try { localStorage.setItem(__wxhlEnemyBackupKey(scope),JSON.stringify(backup)); }
  catch (_) { throw new Error('本地备份保存失败，未执行修复；请释放本地存储空间后重试'); }
  __wxhlEnemyAssertScope(scope);
  const written = await Mvu.replaceMvuData(next,{type:'message',message_id:scope.floor});
  if (written === false) throw new Error('MVU 拒绝了修复，已保留修复前备份');
  __wxhlEnemyAssertScope(scope);
  const reread = __wxhlEnemyRead(scope);
  for (const change of changes) {
    const item = reread.stat_data.契约者.副本角色?.[change.name]?.装备?.[change.slot];
    if (!__wxhlEnemyObject(item) || item.名称 !== '无') throw new Error('修复未通过回读确认，已保留备份：'+change.name+' / '+change.slot);
  }
  toastr.success('已修复 '+changes.length+' 个敌人空槽；修复前备份已保存');
  return true;
}
function __wxhlEnemyExportBackup() {
  const scope = __wxhlEnemyScope();
  const raw = localStorage.getItem(__wxhlEnemyBackupKey(scope));
  if (!raw) { toastr.info('当前聊天、目标楼层还没有修复备份'); return; }
  const blob = new Blob([raw],{type:'application/json;charset=utf-8'});
  const url = URL.createObjectURL(blob),link = document.createElement('a');
  link.href = url;link.download = '敌人空槽修复前备份-第'+scope.floor+'楼.json';
  document.body.appendChild(link);
  try { link.click(); }
  finally { link.remove();setTimeout(()=>URL.revokeObjectURL(url),1000); }
}
async function __wxhlEnemyCopyDraft(id) {
  const text = __wxhlEnemyDraft(id);
  if (!text) { toastr.info('当前聊天没有可复制的本次生成原文'); return; }
  await navigator.clipboard.writeText(text);
  toastr.success('生成原文已复制');
}
const __wxhlEnemyToolsView = {
  __scopeId:'data-v-4e7885b8',
  props:['store'],
  setup(props) {
    const revision = c.ref(0);
    async function act(fn) {
      try { await fn(); }
      catch (error) { toastr.error(error?.message || String(error)); }
      finally { revision.value++; }
    }
    return () => {
      revision.value;
      const store = props.store,busy = store.generatingEnemies || store.writingEnemies;
      // Reading these reactive fields refreshes the draft action after generation.
      const hasDraft = !!__wxhlEnemyDraft(store.current?.id);
      let hasBackup = false;
      try { hasBackup = !!localStorage.getItem(__wxhlEnemyBackupKey(__wxhlEnemyScope())); } catch (_) {}
      return c.h('div',{class:'roll-section',style:{marginTop:'8px'}},[
        c.h('div',{style:{display:'flex',flexWrap:'wrap',gap:'6px'}},[
          c.h('button',{type:'button',class:'confirm-btn modify',disabled:busy,onClick:()=>act(()=>store.repairEnemyEquipment())},'修复旧空槽'),
          hasDraft ? c.h('button',{type:'button',class:'confirm-btn modify',disabled:busy,onClick:()=>act(()=>__wxhlEnemyCopyDraft(store.current?.id))},'复制生成原文') : null,
          hasBackup ? c.h('button',{type:'button',class:'confirm-btn modify',disabled:busy,onClick:()=>act(()=>__wxhlEnemyExportBackup())},'导出修复备份') : null
        ]),
        c.h('div',{class:'set-hint',style:{marginTop:'6px'}},'旧数据修复只处理当前聊天、目标楼层内敌人装备槽的“无”，执行前会预览并备份。')
      ]);
    };
  }
};


