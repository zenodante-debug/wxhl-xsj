// DeepSeek documents JSON Output as response_format.type=json_object.
// Use only the helper's documented custom API body override; never alter host settings.
const __wxhlNoJsonObject = new Set();
const __wxhlNoIzumiTool = new Set();

function __wxhlIsDeepSeekApi(api) {
  if (/deepseek/i.test(String(api.model ?? ''))) return true;
  try { return new URL(api.url).hostname.toLowerCase() === 'api.deepseek.com'; }
  catch (_) { return false; }
}

function __wxhlGenerationError(error) {
  const messages = [error?.message,error?.error?.message,error?.data?.message,
    error?.data?.error?.message,error?.response?.data?.message,
    error?.response?.data?.error?.message,error?.cause?.message,
    error?.code,error?.status,error?.error?.status,error?.data?.error?.status,
    error?.response?.data?.error?.status,
    typeof error === 'string' ? error : null];
  return [...new Set(messages.filter(value => typeof value === 'string' && value.trim()))].join(' | ')
    || String(error);
}

function __wxhlInvalidArgument(message) {
  return /\binvalid[\s_-]+argument\b|request\s+contains\s+(?:an?\s+)?invalid\s+argument/i.test(message);
}

function __wxhlFormatRejected(message) {
  // Authentication, quota and transient availability errors do not establish format support.
  if (/\b(?:401|403|429)\b|unauthori[sz]ed|unauthenticated|authentication|permission[\s_-]*denied|resource[\s_-]*exhausted|(?:invalid|incorrect)[\s_-]*(?:api[\s_-]*)?key|api[\s_-]*key.{0,30}(?:not[\s_-]*valid|invalid|expired)|rate[\s_-]*limit|quota|insufficient.*(?:balance|credits)|model.*(?:not.found|does.not.exist)|密钥|鉴权|余额|限流/i.test(message)) return false;
  const format = /response[\s_-]*format|json[\s_-]*(?:schema|object)|structured[\s_-]*output|custom_include_body|source.{0,30}custom/i.test(message);
  const rejected = /unavailable|unsupported|not[\s_-]*(?:available|supported|support|allowed|permitted)|invalid|unknown|unrecogni[sz]ed|unexpected|not implemented|不支持|不可用|不允许/i.test(message);
  // Retain the previous generic HTTP 400 fallback, but cache it only after a valid reply.
  return (format && rejected) || __wxhlInvalidArgument(message) || /\b400\b|bad\s*request/i.test(message);
}

function __wxhlJsonFormatExample(schema, depth = 0, root = schema) {
  if (!schema || typeof schema !== 'object' || depth > 16) return undefined;
  if (schema.$ref) {
    if (typeof schema.$ref !== 'string' || !schema.$ref.startsWith('#/')) return undefined;
    let target = root;
    try {
      for (const part of decodeURIComponent(schema.$ref.slice(2)).split('/')) {
        const key = part.replace(/~1/g,'/').replace(/~0/g,'~');
        if (!target || !Object.prototype.hasOwnProperty.call(target,key)) return undefined;
        target = target[key];
      }
    } catch (_) { return undefined; }
    return __wxhlJsonFormatExample(target,depth + 1,root);
  }
  if (Object.prototype.hasOwnProperty.call(schema,'const')) return schema.const;
  if (Array.isArray(schema.enum) && schema.enum.length) return schema.enum.find(value => value !== null) ?? schema.enum[0];
  const alternatives = schema.anyOf ?? schema.oneOf;
  if (Array.isArray(alternatives) && alternatives.length)
    return __wxhlJsonFormatExample(alternatives.find(value => value?.type !== 'null') ?? alternatives[0],depth + 1,root);
  const type = Array.isArray(schema.type) ? schema.type.find(value => value !== 'null') : schema.type;
  if (Array.isArray(schema.allOf)) return undefined;
  if (type === 'object' || schema.properties) {
    const entries = Object.entries(schema.properties ?? {}).map(([key,value]) => [key,__wxhlJsonFormatExample(value,depth + 1,root)]);
    return entries.some(([,value]) => value === undefined) ? undefined : Object.fromEntries(entries);
  }
  if (type === 'array') {
    if (schema.maxItems === 0) return [];
    const item = __wxhlJsonFormatExample(schema.items,depth + 1,root);
    return item === undefined ? undefined : [item];
  }
  if (type === 'number' || type === 'integer') return typeof schema.minimum === 'number' ? schema.minimum : 0;
  if (type === 'boolean') return false;
  if (type === 'null') return null;
  return type === 'string' ? '按任务填写' : undefined;
}

async function Dn(e,n,t) {
  if (!e.url || !e.apiKey) throw new Error('API 未配置');
  if (typeof generateRaw !== 'function') throw new Error('generateRaw 不可用');
  const registeredTool = await __wxhlGetIzumiTool();
  const toolKey = registeredTool ? Mn(e) + '::' + JSON.stringify(registeredTool) : '';
  let tool = registeredTool && !__wxhlNoIzumiTool.has(toolKey) ? registeredTool : null;
  const dataSchema = t ? Cn(t.value) : undefined;
  const deepseek = __wxhlIsDeepSeekApi(e), cacheKey = Mn(e);
  const promptSchema = t?.value;
  const instruction = t
    ? '【死命令】结果正文只能是一个合法的 JSON，不能包含 markdown、标题、解释性文字。保留要求的全部字段、层级与完整内容。'
    : '';
  const toolInstruction = tool
    ? '【小手机工具回复兼容】允许通过预设的 izumi_content 提交结果。请把本任务的完整结果放入该工具定义指定的正文字段；思考与正文分开。'
    : '';
  const schemaPrompt = t ? '【结果正文的 JSON 数据结构】\n' + JSON.stringify(promptSchema) : '';
  const toolSchemaPrompt = t ? '【结果正文的 JSON 数据结构】\n' + JSON.stringify(dataSchema) : '';
  const formatExample = t && deepseek && !tool ? __wxhlJsonFormatExample(promptSchema) : undefined;
  const examplePrompt = formatExample !== undefined
    ? '【JSON 格式示例】仅演示字段和层级，不是本次结果；禁止照抄示例值，数组的实际数量与内容按任务要求填写。最终输出业务数据，不要输出 Schema 本身。\n'
      + JSON.stringify(formatExample) : '';
  let format = tool ? 'tool' : !t ? 'text' : registeredTool ? 'prompt' : deepseek
    ? (__wxhlNoJsonObject.has(cacheKey) || !(dataSchema?.type === 'object' || dataSchema?.properties) ? 'prompt' : 'json_object')
    : (Pn.has(cacheKey) ? 'prompt' : 'json_schema');
  let lastError = '', retryInstruction = '', rejectedSchema = false, rejectedObject = false, rejectedTool = false;
  for (let attempt = 0; attempt < 3; attempt++) {
    console.info('[wxhl003] 第'+(attempt+1)+'次调用 model:',e.model);
    const request = {
      user_input:[retryInstruction,instruction,tool ? toolInstruction : '',n,t && format !== 'json_schema' ? (tool ? toolSchemaPrompt : schemaPrompt) : '',examplePrompt].filter(Boolean).join('\n\n'),
      custom_api:{apiurl:e.url,key:e.apiKey,model:e.model},
      ordered_prompts:['user_input'],should_silence:true,should_stream:false,max_chat_history:0
    };
    if (tool) { request.tools = [tool]; request.tool_choice = 'auto'; }
    else if (format === 'json_schema') request.json_schema = {name:t.name,strict:true,value:dataSchema};
    else if (format === 'json_object') {
      request.custom_api.source = 'custom';
      request.custom_api.custom_include_body = {response_format:{type:'json_object'}};
      request.custom_api.custom_exclude_body = [];
      request.custom_api.custom_include_headers = {Authorization:'Bearer '+e.apiKey};
    }
    let response;
    try { response = await generateRaw(request); }
    catch (error) {
      lastError = __wxhlGenerationError(error);
      const rejectedArgument = __wxhlFormatRejected(lastError);
      const downgraded = (format === 'json_schema' || format === 'json_object' || format === 'tool') && rejectedArgument;
      if (downgraded) {
        if (format === 'json_schema') rejectedSchema = true;
        else if (format === 'json_object') rejectedObject = true;
        else { rejectedTool = true; tool = null; }
        format = 'prompt';
        retryInstruction = rejectedTool
          ? '【工具兼容重试】本次不再声明工具。请直接在正文返回完整结果，不要输出工具调用或只填写思考。' + (t ? '正文必须是符合下面完整字段结构的合法 JSON。' : '')
          : '【格式兼容重试】本次已移除格式参数，请按下面完整字段结构直接输出合法 JSON。';
        console.warn('[wxhl003] 请求参数被拒收，移除格式或工具声明后重试');
      } else if (rejectedArgument && __wxhlInvalidArgument(lastError)) {
        // The plain request is still rejected. Repeating it cannot identify or fix
        // a model, sampling, proxy-validation or other remaining argument problem.
        throw new Error('接口拒绝了不带格式参数和工具声明的请求（invalid argument）。请核对模型名、接口地址及预设参数；该报错尚不能确定具体字段。原始错误：'+lastError);
      }
      if (attempt < 2 && !downgraded) await new Promise(resolve => setTimeout(resolve,1500));
      continue;
    }
    let empty = false;
    try {
      const text = __wxhlIzumiReadReply(response,t?.value,tool);
      console.info('[wxhl003] 返回长度:',text.length);
      empty = !text.trim();
      if (empty) throw __wxhlIzumiReplyError(tool
        ? 'API 返回了空正文，也没有可读取的 izumi_content 正文参数。若预设已调用该工具，请确认酒馆助手支持返回工具调用对象。'
        : 'API 返回了空正文，请检查模型回复和最大回复长度。');
      if (t) zn(text);
      // Remember only a format rejection followed by a usable fallback result.
      // Empty or malformed replies alone never mark a provider as unsupported.
      if (rejectedSchema) Pn.add(cacheKey);
      if (rejectedObject) __wxhlNoJsonObject.add(cacheKey);
      if (rejectedTool) __wxhlNoIzumiTool.add(toolKey);
      return text;
    } catch (error) {
      lastError = error?.code === 'WXHL_AI_REPLY' ? error.message
        : t ? 'AI 返回的正文不是可解析的 JSON，请检查生成是否完整。' : 'AI 返回的回复结构无法读取。';
      console.warn('[wxhl003] 回复不可用，准备重试:',lastError);
      // DeepSeek documents occasional empty JSON-mode replies. Retry without the
      // format parameter for this call only, retaining the complete JSON contract.
      if (empty && format === 'json_object') format = 'prompt';
      retryInstruction = '【重试要求】上次未取得有效正文。请重新提交完整结果；' + (tool ? '使用 izumi_content 时必须填写正文字段，不可只提交思考。' : '请直接输出正文，不要输出工具调用或只提交思考。') + (t ? '正文必须为完整合法 JSON，不得省略字段或截断内容。' : '');
      if (attempt < 2) await new Promise(resolve => setTimeout(resolve,1500));
    }
  }
  throw new Error('AI 连续 3 次未返回可用结果。'+(lastError || '生成失败'));
}


