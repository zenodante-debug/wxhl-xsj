const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const root=path.resolve(__dirname,'..');
const candidate=path.resolve(process.argv[2]||path.join(root,'build/小手机v9.json'));
const source=JSON.parse(fs.readFileSync(candidate,'utf8')).content;
const schemaSource=JSON.parse(fs.readFileSync(path.join(root,'scripts/fixtures/variable-structure.json'),'utf8')).content;
const clone=v=>structuredClone(v),j=v=>JSON.parse(JSON.stringify(v));
const _={cloneDeep:clone,clamp:(v,a,b)=>Math.max(a,Math.min(b,v)),pickBy:(o,f)=>Object.fromEntries(Object.entries(o).filter(([k,v])=>f(v,k))),
 get:(o,keys,fallback)=>{let v=o;for(const k of Array.isArray(keys)?keys:String(keys).split('.'))v=v?.[k];return v===undefined?fallback:v;},
 set:(o,keys,v)=>{keys=Array.isArray(keys)?keys:String(keys).split('.');let at=o;for(let i=0;i<keys.length-1;i++)at=at[keys[i]]??={};at[keys.at(-1)]=v;return o;}};
let Z;
function create(){
 const s=source;
 const ctx=vm.createContext({d:Z,z:Z,_,console,c:{ref:v=>({value:v}),h:()=>({})},Map,Set,Date});
 const q=s.indexOf('q={'),qend=s.indexOf('function F(e,',q);vm.runInContext('const '+s.slice(q,qend),ctx);
 const start=s.indexOf('const __wxhlEnemySlots'),end=s.indexOf('function Me(e){',start);
 vm.runInContext(s.slice(start,end),ctx);
 const actual=schemaSource.slice(schemaSource.indexOf('// ==================== 技能'),schemaSource.indexOf('$(() =>')).replace('export const Schema','const Schema');
 vm.runInContext(actual+'\nthis.actual=Schema;',ctx);
 const fp=s.indexOf('function p(e,n){'),fend=s.indexOf('function ',fp+15);
 const sp=s.indexOf('sp=[',s.indexOf('function We(e,n,t)'));
 vm.runInContext('const '+s.slice(sp,s.indexOf('function up(e)',sp)),ctx);
 const ip=s.lastIndexOf('function i(e){',fp);
 vm.runInContext(s.slice(ip,s.indexOf('function A(e){',ip))+s.slice(fp,fend)+'\nthis.calculate=p;',ctx);
 vm.runInContext('this.api={normalize:__wxhlEnemyNormalizeEquipment,prepare:__wxhlEnemyPrepareResponse,empty:__wxhlEnemyEmptySlot,enemy:Ne,response:Ve,entity:Pe,guard:__wxhlEnemyAssertRawAttributes};',ctx);
 return {ctx,api:ctx.api,actual:ctx.actual,calculate:ctx.calculate};
}
function enemy(r,type='杂兵',tier=1,level=5){
 const budget=Math.floor(30+level+{杂兵:.6,精英:.9,BOSS:1.2}[type]*13*tier*tier);
 const values=[Math.floor(budget*.35),Math.floor(budget*.15),Math.floor(budget*.3)];values.push(budget-values.reduce((a,b)=>a+b,0));
 return {名称:'测试'+type,类型:type,等级:level,阶位:['一阶','二阶','三阶','四阶','五阶'][tier-1],
  属性基础:Object.fromEntries(['STR','AGI','CON','PER'].map((k,i)=>[k,values[i]])),属性自定义加成:{STR:0,AGI:0,CON:0,PER:0},衍生额外加成:{},
  装备:{头部:'无',手部:'无'},天赋:{},血统:{},通用技能:{}};
}
function gear(r,name){return {...j(r.api.empty()),名称:name,类型:'武器',品质:'蓝色',阶位:'二阶',描述:'测试装备',效果:{增幅:'造成STR修正×0.3的伤害'}};}
function save(r,raw){const parsed=r.api.enemy.parse(r.api.prepare({敌人:[raw]}).敌人[0]);const name=raw.名称;let data=r.actual.parse({契约者:{副本角色:{[name]:r.api.entity(parsed)}}});r.calculate(data,'契约者.副本角色.'+name);return {name,data: r.actual.parse(data)};}
const tests=[];
async function check(name,fn){await fn();tests.push(name);console.log('PASS',name);}
(async()=>{
 Z=process.env.WXHL_TEST_ZOD ? await import(require('node:url').pathToFileURL(path.resolve(process.env.WXHL_TEST_ZOD)).href) : await import('zod');
 await check('新生成Schema将四维自定义加成限制为0',()=>{const r=create(),raw=enemy(r);raw.属性自定义加成.STR=5;assert.equal(r.api.enemy.safeParse(raw).success,false);assert.throws(()=>r.api.prepare({敌人:[raw]}),/必须为 0/);const schema=Z.toJSONSchema(r.api.response,{io:'input'});assert.equal(schema.properties.敌人.items.properties.属性自定义加成.properties.STR.const,0);});
 await check('纯基础值写入前端后不会变成修正值或被再次加一次',()=>{const r=create(),raw=enemy(r),{name,data}=save(r,raw),entity=data.契约者.副本角色[name];assert.deepEqual(j(entity.属性.基础),raw.属性基础);assert.deepEqual(j(entity.属性.实际),raw.属性基础);assert.equal(entity.属性.属性修正值.STR,raw.属性基础.STR-5);});
 await check('装备职业天赋血统只汇总一次，修正值只按最终属性计算',()=>{const r=create(),raw=enemy(r,'BOSS',2,30);raw.属性基础={STR:20,AGI:18,CON:25,PER:59};const weapon=gear(r,'武器');weapon.主属性='STR';weapon.主属性加成=3;const armor=gear(r,'护甲');armor.装备防御=6;raw.装备={主武器:weapon,躯干:armor};raw.职业={名称:'职业',主属性加成:{属性:'STR',值:4}};raw.天赋={名称:'天赋',属性加成:'STR+2'};raw.血统={名称:'血统',属性加成:'全属性+1'};raw.衍生额外加成={HP额外加成:100,防御额外加成:5};const {name,data}=save(r,raw),e=data.契约者.副本角色[name];assert.equal(e.属性.基础.STR,20);assert.equal(e.属性.加成.STR,10);assert.equal(e.属性.实际.STR,30);assert.equal(e.属性.属性修正值.STR,50);assert.equal(e.衍生属性.HP_最大,1040);assert.equal(e.衍生属性.防御,20);assert.deepEqual(j(e.装备.主武器.效果),weapon.效果);});
 await check('一至五阶的原前端修正系数保持不变',()=>{const r=create();for(const [i,k]of [1,2,4,7,11].entries()){const raw=enemy(r,'精英',i+1,(i+1)*15),{name,data}=save(r,raw);assert.equal(data.契约者.副本角色[name].属性.属性修正值.CON,(raw.属性基础.CON-5)*k);}});
 await check('再次经过Schema和前端代算不会继续增加属性HP防闪',()=>{const r=create(),raw=enemy(r,'BOSS',2,30);const weapon=gear(r,'武器');weapon.主属性='STR';weapon.主属性加成=3;raw.装备.主武器=weapon;raw.血统={名称:'强化',属性加成:'全属性+2'};raw.衍生额外加成={HP额外加成:100};let {name,data}=save(r,raw);const before=j(data.契约者.副本角色[name]);for(let n=0;n<3;n++){r.calculate(data,'契约者.副本角色.'+name);data=r.actual.parse(data);}assert.deepEqual(j(data.契约者.副本角色[name]),before);});
 await check('把装备加成提前塞入基础值时拦截且不猜测扣减',()=>{const r=create(),raw=enemy(r),before=j(raw);raw.属性基础.STR+=10;assert.throws(()=>r.api.prepare({敌人:[raw]}),/裸值预算/);assert.equal(raw.属性基础.STR,before.属性基础.STR+10);});
 await check('把修正值当作高阶基础四维时拦截',()=>{const r=create(),raw=enemy(r,'精英',3,50);for(const key of ['STR','AGI','CON','PER'])raw.属性基础[key]=(raw.属性基础[key]-5)*4;assert.throws(()=>r.api.prepare({敌人:[raw]}),/裸值预算/);});
 await check('原预算向下向上取整均接受，不偷偷重分配四维',()=>{const r=create();for(const type of ['杂兵','精英','BOSS']){const raw=enemy(r,type,2,30),base=j(raw.属性基础);r.api.prepare({敌人:[raw]});assert.deepEqual(raw.属性基础,base);raw.属性基础.PER+=1;r.api.prepare({敌人:[raw]});}});
 await check('夹带最终HP防闪和属性修正值时写入前明确拒绝',()=>{const r=create();for(const key of ['属性','属性修正值','实际属性','HP_最大','防御','闪避值']){const raw=enemy(r);raw[key]=99;assert.throws(()=>r.api.prepare({敌人:[raw]}),new RegExp(key));}});
 await check('四维对象内夹带修正值不会被Schema静默丢弃后写入',()=>{const r=create(),raw=enemy(r);raw.属性基础.STR修正=20;assert.throws(()=>r.api.prepare({敌人:[raw]}),/不能夹带/);});
 await check('独立HP和防御额外加成保留，不被当成重复修正清零',()=>{const r=create(),raw=enemy(r);raw.衍生额外加成={HP额外加成:100,防御额外加成:5};const parsed=r.api.enemy.parse(r.api.prepare({敌人:[raw]}).敌人[0]),entity=r.api.entity(parsed);assert.equal(entity.衍生属性.HP额外加成,100);assert.equal(entity.衍生属性.防御额外加成,5);});
 await check('空槽修复及完整装备结构保留',()=>{const r=create(),raw=enemy(r),p=r.api.prepare({敌人:[raw]}).敌人[0];assert.deepEqual(j(p.装备.头部),j(r.api.empty()));const item=gear(r,'保留武器');raw.装备.主武器=item;assert.deepEqual(j(r.api.prepare({敌人:[raw]}).敌人[0].装备.主武器),item);});
 await check('生成及批量写入两条入口都执行裸属性检查',()=>{assert.ok(source.includes('__wxhlEnemyAssertRawAttributes(enemy);'));assert.ok(source.includes('a.map(({i,slot})=>{__wxhlEnemyAssertRawAttributes(slot.数据);'));});
 await check('写入实体不含实际属性、修正值和最终衍生属性',()=>{const r=create(),raw=enemy(r),parsed=r.api.enemy.parse(r.api.prepare({敌人:[raw]}).敌人[0]),entity=r.api.entity(parsed);assert.equal(entity.属性.实际,undefined);assert.equal(entity.属性.属性修正值,undefined);assert.equal(entity.衍生属性.HP_最大,undefined);assert.equal(entity.衍生属性.防御,undefined);});
 await check('提示词不再要求AI计算修正公式与最终状态卡',()=>{const a=source.indexOf('generateEnemies:async function'),g=source.slice(a,source.indexOf('writeEnemies:async function',a));assert.ok(!g.includes('修正值 =（实际属性值'));assert.ok(!g.includes('AI输出的<enemy>状态卡数值必须'));assert.ok(g.includes('本模块最终写入约束'));assert.ok(g.includes('技能、天赋、血统和装备效果中的'));});
})().catch(error=>{console.error(error);process.exitCode=1;});
