#!/usr/bin/env python3
"""Reassemble the delivered runtime and export a Tavern Helper script JSON."""
import argparse
import hashlib
import json
import shutil
import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def read_text(path):
    return path.read_bytes().decode("utf-8")

def digest(data):
    return hashlib.sha256(data).hexdigest()

def assemble(manifest):
    source = read_text(ROOT / "src/bundle.template.mjs")
    for part in manifest["parts"]:
        marker = part["marker"]
        if source.count(marker) != 1:
            raise ValueError(f"拼接标记缺失或重复：{marker}")
        content = read_text(ROOT / part["file"])
        if part["format"] == "json-string":
            content = json.dumps(content, ensure_ascii=False)
        elif part["format"] != "javascript":
            raise ValueError(f"未知片段格式：{part['format']}")
        source = source.replace(marker, content, 1)
    script = json.loads(read_text(ROOT / "src/script-template.json"))
    if script.get("type") != "script" or script.get("id") != manifest["script_id"]:
        raise ValueError("酒馆助手脚本类型或 ID 与项目配置不一致")
    script["content"] = source
    raw = (json.dumps(script, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    return source.encode("utf-8"), raw

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    action = parser.add_mutually_exclusive_group()
    action.add_argument("--output", type=Path, help="输出路径，默认 build/小手机v9.json")
    action.add_argument("--check", action="store_true", help="验证能逐字节重建已交付版本，并检查 JavaScript 语法")
    args = parser.parse_args()
    manifest = json.loads(read_text(ROOT / "project.json"))
    runtime, raw = assemble(manifest)
    if args.check:
        release = (ROOT / manifest["release_file"]).read_bytes()
        if digest(runtime) != manifest["runtime_sha256"]:
            raise SystemExit("运行代码与本次交付的摘要不同")
        if raw != release or digest(raw) != manifest["release_sha256"]:
            raise SystemExit("重新打包的导入文件与本次交付的 JSON 不一致")
        node = shutil.which("node")
        if not node:
            raise SystemExit("语法检查需要 Node.js；单独构建只需要 Python 3")
        with tempfile.TemporaryDirectory(prefix=".check-", dir=ROOT) as tmp:
            path = Path(tmp) / "phone.mjs"
            path.write_bytes(runtime)
            subprocess.run([node, "--check", str(path)], check=True)
        print(f"逐字节重建和语法检查通过：{len(raw)} 字节，SHA-256 {digest(raw)}")
        return
    target = (args.output or ROOT / "build/小手机v9.json").resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    print(f"已生成 {target}（{len(raw)} 字节）")

if __name__ == "__main__":
    main()
