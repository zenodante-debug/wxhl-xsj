# 无限回廊 · 小手机 v9

本仓库保存 2026-10-26 交付的工坊改造整合版，包含敌人装备空槽修复和裸基础属性检查。源码、构建脚本和可导入的酒馆助手 JSON 已按同一版本配套。

直接下载 [酒馆助手脚本-小手机v9-工坊改造整合版.json](release/酒馆助手脚本-小手机v9-工坊改造整合版.json)，在酒馆助手中导入并替换同 ID 的小手机脚本。

| 文件 | 用途 |
| --- | --- |
| `src/bundle.template.mjs` | 完整的 JavaScript 运行代码主体 |
| `src/parts/bootstrap.mjs` | 浏览器依赖加载和备用地址 |
| `src/parts/dungeon-rules.js` | 副本规则、骰表和模块开关 |
| `src/parts/enemy-data.js` | 敌人装备、裸属性检查和旧空槽修复 |
| `src/parts/ai-transport.js` | AI 请求格式和工具调用兼容 |
| `src/styles/phone.css` | 主界面样式 |
| `src/script-template.json`、`project.json` | 酒馆助手脚本元数据、构建配置和摘要 |

在仓库根目录运行：

```bash
python3 scripts/build.py
python3 scripts/build.py --check
```

第一条生成 `build/小手机v9.json`；第二条检查 JavaScript 语法，并确认可以逐字节重建 `release/` 中的交付版。构建只需要 Python 3，语法检查需要 Node.js。

如需运行敌人生成回归检查：

```bash
npm install
npm test
```

检查使用 `scripts/fixtures/` 中的变量结构样例，在本地运行选定的计算函数，不连接酒馆或模型接口。导入时使用 `release/` 的脚本 JSON。

当前维护工程以已交付的运行代码为准。[原始 Vue / TypeScript 工程](https://github.com/zenodante-debug/wxhl-cj/tree/087fca510e743f15ae11c659e02c7dd94d60bfdc/src/wxhl-003) 保留在原仓库；后续加入的补丁在这里随运行代码维护。运行时沿用原角色卡对应的 SillyTavern、酒馆助手和 MVU 环境。许可证见 [LICENSE](LICENSE)。
